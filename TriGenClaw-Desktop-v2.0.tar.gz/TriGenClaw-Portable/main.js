/* ========================================
   Electron 主进程
   窗口管理、系统托盘、快捷键、菜单、IPC、自动更新
   ======================================== */
const { app, BrowserWindow, Tray, Menu, globalShortcut, ipcMain, dialog, shell, nativeImage, clipboard, net, session } = require('electron');
const path = require('path');
const fs = require('fs');
const OfflineCache = require('./offline-cache');

// ===== 常量 =====
const isDev = process.argv.includes('--dev') || !app.isPackaged;
const APP_NAME = 'TriGenClaw';
const WINDOW_WIDTH = 1280;
const WINDOW_HEIGHT = 800;
const MIN_WIDTH = 800;
const MIN_HEIGHT = 600;

// ===== 本地缓存配置 =====
const CACHE_DIR = path.join(app.getPath('userData'), 'cache');
const CACHE_DB = path.join(CACHE_DIR, 'cache-data.json');
let offlineCache = null;

// ===== 离线检测和网络状态监控 =====
let isOffline = !net.isOnline();

// ===== IPC 请求拦截器配置 =====
const CACHEABLE_PROTOCOLS = ['https:', 'http:'];
const API_CACHE_TTL = 3600000; // 1小时缓存
const STATIC_CACHE_TTL = 86400000; // 24小时缓存

let mainWindow = null;
let tray = null;
let isQuitting = false;
let currentProjectPath = null;

// ===== 文件系统沙箱：限制 IPC 文件操作到项目目录 =====
const ALLOWED_BASE_DIR = path.resolve(__dirname);

function isPathSafe(targetPath) {
  try {
    const resolved = path.resolve(targetPath);
    const allowed = [ALLOWED_BASE_DIR];
    if (currentProjectPath) {
      allowed.push(path.resolve(currentProjectPath));
    }
    return allowed.some(function(base) {
      return resolved.startsWith(base + path.sep) || resolved === base;
    });
  } catch(e) {
    return false;
  }
}

// ===== 网络状态监听 =====
function setupNetworkMonitoring() {
  // 监听网络连接状态变化
  net.on('-connection', function(event) {
    isOffline = !net.isOnline();
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('network-status', isOffline);
    }
  });

  // 设置请求拦截器 - 优先使用本地缓存
  session.defaultSession.webRequest.onBeforeRequest(function(details, callback) {
    // 只处理可缓存的协议
    try {
      var urlObj = new URL(details.url);
      if (!CACHEABLE_PROTOCOLS.includes(urlObj.protocol)) {
        callback({});
        return;
      }
    } catch(e) {
      callback({});
      return;
    }

    // 离线模式下，尝试从缓存读取
    if (isOffline && offlineCache) {
      var cached = offlineCache.get(details.url);
      if (cached) {
        callback({
          redirectURL: cached
        });
        return;
      }
    }
    callback({});
  }, function(error) {
    if (error) console.error('请求拦截器错误:', error);
  });
}

// ===== 初始化离线缓存 =====
function initOfflineCache() {
  try {
    if (!fs.existsSync(CACHE_DIR)) {
      fs.mkdirSync(CACHE_DIR, { recursive: true });
    }
    offlineCache = new OfflineCache(CACHE_DIR);
    console.log('离线缓存已初始化:', CACHE_DIR);
  } catch (e) {
    console.error('离线缓存初始化失败:', e);
  }
}

// ===== 主窗口 =====
function createWindow() {
  mainWindow = new BrowserWindow({
    width: WINDOW_WIDTH,
    height: WINDOW_HEIGHT,
    minWidth: MIN_WIDTH,
    minHeight: MIN_HEIGHT,
    title: APP_NAME,
    backgroundColor: '#0f0f23',
    show: false,
    icon: path.join(__dirname, 'build', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true
    }
  });

  mainWindow.loadFile('index.html');

  // 添加 Content-Security-Policy 安全策略
  mainWindow.webContents.session.webRequest.onHeadersReceived(function(details, callback) {
    callback({
      responseHeaders: Object.assign({
        'Content-Security-Policy': ["default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; connect-src 'self' https://j3trisheng.com https://api.j3trisheng.com; img-src 'self' data: blob:;"]
      }, details.responseHeaders)
    });
  });

  // 窗口就绪后显示（避免白屏）
  mainWindow.once('ready-to-show', function() {
    mainWindow.show();
    if (isDev) mainWindow.webContents.openDevTools();
  });

  // 最小化时隐藏到托盘
  mainWindow.on('minimize', function(e) {
    e.preventDefault();
    mainWindow.hide();
  });

  mainWindow.on('close', function(e) {
    if (!isQuitting) {
      e.preventDefault();
      mainWindow.hide();
    }
  });

  mainWindow.on('closed', function() {
    mainWindow = null;
  });
}

// ===== 系统托盘 =====
function createTray() {
  // Electron 主进程没有 DOM，使用 nativeImage 从文件创建
  const iconPath = path.join(__dirname, 'build', 'tray-icon.png');
  let trayIcon;
  try {
    trayIcon = nativeImage.createFromPath(iconPath);
    if (trayIcon.isEmpty()) {
      // 创建纯色图标
      const size = 16;
      const buf = Buffer.alloc(size * size * 4);
      for (let i = 0; i < size * size; i++) {
        const x = i % size;
        const y = Math.floor(i / size);
        const cx = size / 2, cy = size / 2;
        const dist = Math.sqrt((x - cx) ** 2 + (y - cy) ** 2);
        if (dist < size / 2) {
          buf[i * 4] = 0;     // R
          buf[i * 4 + 1] = 212; // G
          buf[i * 4 + 2] = 255; // B
          buf[i * 4 + 3] = 200; // A
        } else {
          buf[i * 4 + 3] = 0; // transparent
        }
      }
      trayIcon = nativeImage.createFromBuffer(buf, { width: size, height: size });
    }
  } catch (e) {
    trayIcon = nativeImage.createEmpty();
  }

  tray = new Tray(trayIcon);
  tray.setToolTip(APP_NAME);

  const contextMenu = Menu.buildFromTemplate([
    { label: '显示 ' + APP_NAME, click: showWindow },
    { type: 'separator' },
    { label: '新对话', click: function() { sendToRenderer('action', 'new-chat'); showWindow(); } },
    { label: '打开代码', click: function() { sendToRenderer('action', 'open-code'); showWindow(); } },
    { label: 'Agent 工作台', click: function() { sendToRenderer('action', 'open-agent'); showWindow(); } },
    { type: 'separator' },
    { label: '? 贾维斯模式', click: function() { sendToRenderer('action', 'toggle-jarvis'); showWindow(); } },
    { type: 'separator' },
    { label: '退出', click: function() { isQuitting = true; app.quit(); } }
  ]);

  tray.setContextMenu(contextMenu);
  tray.on('double-click', showWindow);
}

function showWindow() {
  if (mainWindow) {
    mainWindow.show();
    mainWindow.focus();
  }
}

// ===== 原生菜单 =====
function createMenu() {
  const template = [
    {
      label: '文件',
      submenu: [
        { label: '新建文件', accelerator: 'CmdOrCtrl+N', click: function() { sendToRenderer('action', 'new-file'); } },
        { label: '打开文件夹...', accelerator: 'CmdOrCtrl+O', click: openFolderDialog },
        { type: 'separator' },
        { label: '保存', accelerator: 'CmdOrCtrl+S', click: function() { sendToRenderer('action', 'save-file'); } },
        { label: '另存为...', accelerator: 'CmdOrCtrl+Shift+S', click: saveFileDialog },
        { type: 'separator' },
        { label: '退出', accelerator: 'CmdOrCtrl+Q', click: function() { isQuitting = true; app.quit(); } }
      ]
    },
    {
      label: '编辑',
      submenu: [
        { role: 'undo', label: '撤销' },
        { role: 'redo', label: '重做' },
        { type: 'separator' },
        { role: 'cut', label: '剪切' },
        { role: 'copy', label: '复制' },
        { role: 'paste', label: '粘贴' },
        { role: 'selectAll', label: '全选' }
      ]
    },
    {
      label: '视图',
      submenu: [
        { label: '开发者工具', accelerator: 'F12', click: function() { mainWindow?.webContents.toggleDevTools(); } },
        { type: 'separator' },
        { label: '放大', accelerator: 'CmdOrCtrl+=', role: 'zoomIn' },
        { label: '缩小', accelerator: 'CmdOrCtrl+-', role: 'zoomOut' },
        { label: '重置缩放', accelerator: 'CmdOrCtrl+0', role: 'resetZoom' },
        { type: 'separator' },
        { label: '切换全屏', accelerator: 'F11', role: 'togglefullscreen' }
      ]
    },
    {
      label: '帮助',
      submenu: [
        { label: '关于 ' + APP_NAME, click: showAboutDialog },
        { type: 'separator' },
        { label: '检查更新', click: checkForUpdates }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

// ===== 对话框 =====
async function openFolderDialog() {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openDirectory'],
    title: '选择项目文件夹'
  });
  if (!result.canceled && result.filePaths.length > 0) {
    currentProjectPath = result.filePaths[0];
    sendToRenderer('project:open', { path: currentProjectPath });
    // 读取目录结构
    const tree = readDirectoryTree(currentProjectPath);
    sendToRenderer('project:tree', tree);
  }
}

async function saveFileDialog() {
  const result = await dialog.showSaveDialog(mainWindow, {
    filters: [
      { name: '所有文件', extensions: ['*'] },
      { name: 'JavaScript', extensions: ['js', 'jsx', 'ts', 'tsx'] },
      { name: 'HTML', extensions: ['html', 'htm'] },
      { name: 'CSS', extensions: ['css', 'scss', 'less'] },
      { name: 'JSON', extensions: ['json'] },
      { name: 'Markdown', extensions: ['md', 'markdown'] }
    ]
  });
  if (!result.canceled && result.filePath) {
    sendToRenderer('project:save-as', { path: result.filePath });
  }
}

function showAboutDialog() {
  dialog.showMessageBox(mainWindow, {
    type: 'info',
    title: '关于 ' + APP_NAME,
    message: APP_NAME,
    detail: '版本 ' + app.getVersion() + '\n\n' +
      '下一代 AI 桌面工作台\n' +
      '集成 300+ 模型、代码助手、Agent 编排、技能生态\n\n' +
      'Electron: ' + process.versions.electron + '\n' +
      'Node: ' + process.versions.node + '\n' +
      'Chromium: ' + process.versions.chrome,
    buttons: ['确定']
  });
}

// ===== 自动更新 =====
let updateChecking = false;

function checkForUpdates() {
  if (updateChecking) return;
  updateChecking = true;

  try {
    const { autoUpdater } = require('electron-updater');
    autoUpdater.autoDownload = false;
    autoUpdater.setFeedURL({
      provider: 'generic',
      url: 'https://releases.trigenclaw.com'
    });

    autoUpdater.on('update-available', function(info) {
      updateChecking = false;
      dialog.showMessageBox(mainWindow, {
        type: 'info',
        title: '发现更新',
        message: '新版本 ' + info.version + ' 可用',
        detail: '当前版本: ' + app.getVersion() + '\n新版本: ' + info.version,
        buttons: ['下载更新', '稍后']
      }).then(function(result) {
        if (result.response === 0) {
          autoUpdater.downloadUpdate();
        }
      });
    });

    autoUpdater.on('update-not-available', function() {
      updateChecking = false;
      dialog.showMessageBox(mainWindow, {
        type: 'info',
        title: '已是最新',
        message: APP_NAME + ' 已是最新版本',
        detail: '当前版本: ' + app.getVersion()
      });
    });

    autoUpdater.on('download-progress', function(progress) {
      sendToRenderer('update:progress', progress);
    });

    autoUpdater.on('update-downloaded', function(info) {
      dialog.showMessageBox(mainWindow, {
        type: 'question',
        title: '更新已就绪',
        message: '更新已下载完成，是否立即安装？',
        buttons: ['立即安装', '稍后重启']
      }).then(function(result) {
        if (result.response === 0) {
          autoUpdater.quitAndInstall();
        }
      });
    });

    autoUpdater.on('error', function(err) {
      updateChecking = false;
      if (isDev) {
        dialog.showMessageBox(mainWindow, {
          type: 'info',
          title: '更新检查',
          message: '开发模式下跳过更新检查',
          detail: err ? err.message : ''
        });
      }
    });

    autoUpdater.checkForUpdates();

  } catch (e) {
    updateChecking = false;
  }
}

// ===== 全局快捷键 =====
function registerShortcuts() {
  // Alt+Space 唤起/隐藏
  globalShortcut.register('Alt+Space', function() {
    if (mainWindow) {
      if (mainWindow.isVisible()) {
        mainWindow.hide();
      } else {
        showWindow();
      }
    }
  });

  // Ctrl+Shift+V 切换贾维斯模式
  globalShortcut.register('Ctrl+Shift+V', function() {
    sendToRenderer('action', 'toggle-jarvis');
    showWindow();
  });
}

// ===== 文件系统 IPC =====
function setupIPC() {
  // 读取目录树（安全路径校验）
  ipcMain.handle('file:list', async function(event, dirPath) {
    try {
      const target = dirPath || currentProjectPath || __dirname;
      if (!isPathSafe(target)) return { error: '无权访问该目录', path: target, items: [] };
      return readDirectoryTree(target);
    } catch (e) {
      return { error: e.message, path: dirPath, items: [] };
    }
  });

  // 读取文件（安全路径校验）
  ipcMain.handle('file:read', async function(event, filePath) {
    try {
      if (!isPathSafe(filePath)) return { success: false, error: '无权访问该文件' };
      const content = fs.readFileSync(filePath, 'utf-8');
      return { success: true, content: content };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });

  // 写入文件（安全路径校验）
  ipcMain.handle('file:write', async function(event, filePath, content) {
    try {
      if (!isPathSafe(filePath)) return { success: false, error: '无权写入该路径' };
      const dir = path.dirname(filePath);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(filePath, content, 'utf-8');
      return { success: true };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });

  // 删除文件（安全路径校验）
  ipcMain.handle('file:delete', async function(event, filePath) {
    try {
      if (!isPathSafe(filePath)) return { success: false, error: '无权删除该文件' };
      fs.unlinkSync(filePath);
      return { success: true };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });

  // 创建文件（安全路径校验）
  ipcMain.handle('file:create', async function(event, filePath) {
    try {
      if (!isPathSafe(filePath)) return { success: false, error: '无权在该路径创建文件' };
      const dir = path.dirname(filePath);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(filePath, '', 'utf-8');
      return { success: true };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });

  // 选择文件夹对话框
  ipcMain.handle('dialog:select-folder', async function() {
    const result = await dialog.showOpenDialog(mainWindow, { properties: ['openDirectory'] });
    if (!result.canceled && result.filePaths.length > 0) {
      currentProjectPath = result.filePaths[0];
      return { success: true, path: currentProjectPath };
    }
    return { success: false };
  });

  // 获取应用版本
  ipcMain.handle('app:version', function() {
    return app.getVersion();
  });

  // 获取平台信息
  ipcMain.handle('app:platform', function() {
    return {
      platform: process.platform,
      electronVersion: process.versions.electron,
      nodeVersion: process.versions.node,
      chromeVersion: process.versions.chrome
    };
  });

  // 打开文件选择对话框
  ipcMain.handle('dialog:open-file', async function(event, opts) {
    const result = await dialog.showOpenDialog(mainWindow, {
      properties: ['openFile'],
      filters: opts?.filters || [{ name: '所有文件', extensions: ['*'] }]
    });
    if (!result.canceled && result.filePaths.length > 0) {
      return { success: true, path: result.filePaths[0] };
    }
    return { success: false };
  });

  // 打开外部链接
  ipcMain.handle('shell:open-external', async function(event, url) {
    // 安全校验：仅允许 https 和 http 协议
    if (typeof url !== 'string') return;
    try {
      var parsed = new URL(url);
      if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') return;
    } catch(e) { return; }
    shell.openExternal(url);
  });

  // 设置窗口大小
  ipcMain.handle('window:set-size', function(event, width, height) {
    if (mainWindow) mainWindow.setSize(width, height);
  });

  // 搜索文件
  ipcMain.handle('device:search-file', async function(event, query) {
    try {
      const homeDir = require('os').homedir();
      const results = [];
      function walk(dir, depth) {
        if (depth > 3) return; // 限制递归深度
        try {
          const entries = fs.readdirSync(dir, { withFileTypes: true });
          for (const entry of entries) {
            if (entry.name.startsWith('.') || entry.name === 'node_modules') continue;
            const fullPath = path.join(dir, entry.name);
            if (entry.name.toLowerCase().includes(query.toLowerCase())) {
              results.push({ name: entry.name, path: fullPath, type: entry.isDirectory() ? 'directory' : 'file' });
              if (results.length >= 10) return;
            }
            if (entry.isDirectory()) {
              walk(fullPath, depth + 1);
              if (results.length >= 10) return;
            }
          }
        } catch(e) {}
      }
      walk(homeDir, 0);
      return { success: true, results: results };
    } catch(e) {
      return { success: false, error: e.message, results: [] };
    }
  });

  // 打开文件/文件夹
  ipcMain.handle('shell:open-path', async function(event, filePath) {
    try {
      shell.openPath(filePath);
      return { success: true };
    } catch(e) {
      return { success: false, error: e.message };
    }
  });

  // ===== 离线缓存 IPC =====
  // 获取缓存数据
  ipcMain.handle('cache:get', function(event, key) {
    try {
      if (!offlineCache) return null;
      var item = offlineCache.get(key);
      if (item && !offlineCache.isExpired(key)) {
        return item.value;
      }
      return null;
    } catch(e) {
      return null;
    }
  });

  // 设置缓存数据
  ipcMain.handle('cache:set', function(event, key, value, ttl) {
    try {
      if (!offlineCache) return false;
      return offlineCache.set(key, value, ttl);
    } catch(e) {
      return false;
    }
  });

  // 检查缓存是否存在且未过期
  ipcMain.handle('cache:has', function(event, key) {
    try {
      if (!offlineCache) return false;
      var item = offlineCache.get(key);
      if (!item) return false;
      return !offlineCache.isExpired(key);
    } catch(e) {
      return false;
    }
  });

  // 清除过期缓存
  ipcMain.handle('cache:cleanup', function() {
    try {
      if (!offlineCache) return false;
      return offlineCache.cleanup();
    } catch(e) {
      return false;
    }
  });

  // 获取网络状态
  ipcMain.handle('network:status', function() {
    return { isOffline: isOffline };
  });

  // 获取缓存目录
  ipcMain.handle('cache:dir', function() {
    return CACHE_DIR;
  });
}

function readDirectoryTree(dirPath) {
  const items = [];
  try {
    const entries = fs.readdirSync(dirPath, { withFileTypes: true });
    for (const entry of entries) {
      // 跳过隐藏文件和 node_modules
      if (entry.name.startsWith('.') || entry.name === 'node_modules') continue;
      items.push({
        name: entry.name,
        type: entry.isDirectory() ? 'directory' : 'file',
        path: path.join(dirPath, entry.name)
      });
    }
    // 目录优先，然后按名称排序
    items.sort(function(a, b) {
      if (a.type !== b.type) return a.type === 'directory' ? -1 : 1;
      return a.name.localeCompare(b.name);
    });
  } catch (e) {}
  return items;
}

// ===== 发送消息到渲染进程 =====
function sendToRenderer(channel, data) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send(channel, data);
  }
}

// ===== 应用生命周期 =====
app.whenReady().then(function() {
  // 初始化离线缓存
  initOfflineCache();

  // 设置网络状态监控
  setupNetworkMonitoring();

  createWindow();
  createMenu();
  setupIPC();
  registerShortcuts();

  // 延迟创建托盘（需要等窗口显示后）
  setTimeout(createTray, 1000);

  // 首次启动时通知渲染进程当前网络状态
  setTimeout(function() {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('network-status', isOffline);
    }
  }, 2000);

  // 自动检查更新（非开发模式）
  if (!isDev) {
    setTimeout(checkForUpdates, 5000);
  }
});

app.on('window-all-closed', function() {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', function() {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  } else {
    showWindow();
  }
});

app.on('before-quit', function() {
  isQuitting = true;
});

app.on('will-quit', function() {
  globalShortcut.unregisterAll();
});
