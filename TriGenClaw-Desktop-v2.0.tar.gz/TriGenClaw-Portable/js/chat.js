/* ========================================
   对话核心模块 - 流式响应、历史管�?   ======================================== */
var NexusChat = (function() {
  'use strict';

  var STORAGE_KEY = 'nx_chat_history';
  var messages = [];  // 当前对话消息
  var historyList = []; // 历史对话列表
  var currentHistoryId = null;
  var abortController = null;
  var isStreaming = false;
  var onMessagesChange = null;
  var _systemPrompt = '';
  var _temperature = 0.7;
  var _maxTokens = 4096;
  var _ragEnabled = true;
  var _ragMaxResults = 3;
  var _ragMinScore = 0.3;
  var _lastRagContext = null;

  /** 加载历史列表 */
  function loadHistory() {
    try {
      var data = localStorage.getItem(STORAGE_KEY);
      historyList = data ? JSON.parse(data) : [];
    } catch (e) {
      historyList = [];
    }
    return historyList;
  }

  /** 保存历史列表 */
  function saveHistory() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(historyList));
    } catch (e) {
      // 存储空间不足时忽�?    }
  }

  /** 新建对话 */
  function newChat() {
    // 如果当前对话有内容，保存到历�?    if (messages.length > 0 && currentHistoryId) {
      saveCurrentToHistory();
    }
    messages = [];
    currentHistoryId = generateId();
    if (typeof onMessagesChange === 'function') onMessagesChange(messages);
    return currentHistoryId;
  }

  /** 生成唯一 ID */
  function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  }

  /** 保存当前对话到历�?*/
  function saveCurrentToHistory() {
    if (messages.length === 0) return;
    var title = getFirstMessageText();
    var existing = -1;
    for (var i = 0; i < historyList.length; i++) {
      if (historyList[i].id === currentHistoryId) {
        existing = i;
        break;
      }
    }
    var entry = {
      id: currentHistoryId,
      title: title,
      messages: messages,
      model: NexusModels.getCurrentModel(),
      systemPrompt: _systemPrompt,
      temperature: _temperature,
      maxTokens: _maxTokens,
      updatedAt: Date.now()
    };
    if (existing >= 0) {
      historyList[existing] = entry;
    } else {
      historyList.unshift(entry);
    }
    // 限制历史数量
    if (historyList.length > 100) historyList = historyList.slice(0, 100);
    saveHistory();
  }

  /** 获取第一条用户消息作为标�?*/
  function getFirstMessageText() {
    for (var i = 0; i < messages.length; i++) {
      if (messages[i].role === 'user') {
        var text = messages[i].content;
        return text.length > 40 ? text.slice(0, 40) + '...' : text;
      }
    }
    return '新对�?;
  }

  /** 加载历史对话 */
  function loadChat(historyId) {
    // 保存当前
    if (messages.length > 0 && currentHistoryId) {
      saveCurrentToHistory();
    }
    for (var i = 0; i < historyList.length; i++) {
      if (historyList[i].id === historyId) {
        messages = JSON.parse(JSON.stringify(historyList[i].messages)) || [];
        currentHistoryId = historyId;
        _systemPrompt = historyList[i].systemPrompt || '';
        _temperature = historyList[i].temperature || 0.7;
        _maxTokens = historyList[i].maxTokens || 4096;
        if (typeof onMessagesChange === 'function') onMessagesChange(messages);
        return true;
      }
    }
    return false;
  }

  /** 删除历史对话 */
  function deleteHistory(historyId) {
    historyList = historyList.filter(function(h) { return h.id !== historyId; });
    saveHistory();
    if (currentHistoryId === historyId) {
      messages = [];
      currentHistoryId = generateId();
      if (typeof onMessagesChange === 'function') onMessagesChange(messages);
    }
  }

  /** 添加消息（本地） */
  function addMessage(role, content) {
    messages.push({ role: role, content: content, timestamp: Date.now() });
    if (typeof onMessagesChange === 'function') onMessagesChange(messages);
  }

  /** 更新最后一条助手消息（用于流式追加�?*/
  function updateLastAssistant(content) {
    for (var i = messages.length - 1; i >= 0; i--) {
      if (messages[i].role === 'assistant') {
        messages[i].content = content;
        if (typeof onMessagesChange === 'function') onMessagesChange(messages);
        return;
      }
    }
    // 如果没有助手消息，创建一�?    messages.push({ role: 'assistant', content: content });
    if (typeof onMessagesChange === 'function') onMessagesChange(messages);
  }

  /** 发送消�?*/
  function sendMessage(userContent) {
    if (isStreaming) return;
    if (!userContent || !userContent.trim()) return;

    // 确保有当前对�?ID
    if (!currentHistoryId || messages.length === 0) {
      currentHistoryId = generateId();
    }

    // 添加用户消息
    addMessage('user', userContent);
    var model = NexusModels.getCurrentModel();

    // 添加占位助手消息
    addMessage('assistant', '');
    isStreaming = true;
    var fullContent = '';

    // 构建消息列表
    var apiMessages = [];
    if (_systemPrompt) {
      apiMessages.push({ role: 'system', content: _systemPrompt });
    }
    apiMessages = apiMessages.concat(messages.map(function(m) {
      return { role: m.role, content: m.content || '' };
    }));
    // RAG：搜索知识库获取上下�?    if (typeof NexusKnowledge !== 'undefined' && NexusKnowledge.searchRelevant && _ragEnabled) {
      var ragResults = NexusKnowledge.searchRelevant(userContent, _ragMaxResults);
      if (ragResults && ragResults.length > 0) {
        var contextParts = ['以下是从知识库中检索到的相关上下文�?];
        for (var r = 0; r < ragResults.length; r++) {
          if (ragResults[r].score >= _ragMinScore) {
            var snippet = ragResults[r].text.replace(/\n/g, ' ').substring(0, 400);
            contextParts.push('�? + ragResults[r].title + '�? + snippet);
          }
        }
        if (contextParts.length > 1) {
          var ragText = contextParts.join('\n\n') + '\n\n请基于以上上下文回答用户的问题。如果上下文不相关或不充分，请说明�?;
          apiMessages.unshift({ role: 'system', content: ragText });
          _lastRagContext = ragResults.filter(function(r) { return r.score >= _ragMinScore; });
        }
      }
    }

    if (typeof NexusPlugins !== 'undefined' && NexusPlugins.dispatch) {
      apiMessages = NexusPlugins.dispatch('onBeforeSend', apiMessages);
    }

    abortController = NexusAPI.chatStream(
      model,
      apiMessages,
      function(chunk) {
        fullContent += chunk;
        updateLastAssistant(fullContent);
      },
      function() {
        isStreaming = false;
        abortController = null;
        notifyResponse(fullContent);
        if (typeof NexusPlugins !== 'undefined' && NexusPlugins.dispatch) {
          NexusPlugins.dispatch('onAfterResponse', { content: fullContent });
        }
        // 自动保存到历�?        saveCurrentToHistory();
      },
      function(err) {
        isStreaming = false;
        abortController = null;
        updateLastAssistant('抱歉，请求出错：' + err);
      },
      { temperature: _temperature, max_tokens: _maxTokens }
    );
  }

  /** 取消流式响应 */
  function cancelStream() {
    if (abortController) {
      abortController.abort();
      abortController = null;
      isStreaming = false;
    }
  }

  /** 获取当前消息 */
  function getMessages() {
    return messages;
  }

  /** 获取历史列表 */
  function getHistoryList() {
    return historyList;
  }

  /** 设置消息变更回调 */
  function onMessagesChangeCallback(callback) {
    onMessagesChange = callback;
  }

  function branch(index) {
    if (index < 0 || index >= messages.length) return;
    if (currentHistoryId) saveCurrentToHistory();
    messages = messages.slice(0, index + 1);
    currentHistoryId = generateId();
    saveCurrentToHistory();
    if (typeof onMessagesChange === 'function') onMessagesChange(messages);
  }

  function requestNotify() {
    if (typeof Notification !== 'undefined' && Notification.permission === 'default') {
      Notification.requestPermission();
    }
  }

  function notifyResponse(content) {
    if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
      try { new Notification('TriGenClaw', { body: (content || '').substring(0, 100) }); } catch(e) {}
    }
  }

  /** 发送代码分析请�?*/
  function updateMessage(index, content) {
    if (index >= 0 && index < messages.length) {
      messages[index].content = content;
      if (typeof onMessagesChange === 'function') onMessagesChange(messages);
    }
  }

  function analyzeCode(code, action, callback) {
    var actionPrompts = {
      review: '你是一个专业的代码审查专家。请对以下代码进行全面的代码审查，包括：代码质量、潜在bug、性能问题、安全性、最佳实践等方面。用中文回复�?,
      explain: '你是一个耐心的编程导师。请详细解释以下代码的功能、工作原理、关键逻辑和设计模式。用中文回复�?,
      optimize: '你是一个性能优化专家。请分析以下代码的性能瓶颈，并提供优化建议和优化后的代码。用中文回复�?
    };

    var systemPrompt = actionPrompts[action] || actionPrompts.review;
    var userPrompt = '`\n' + code + '\n`\n\n�? + (action === 'review' ? '审查' : action === 'explain' ? '解释' : '优化') + '这段代码�?;

    var apiMessages = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt }
    ];

    var model = NexusModels.getCurrentModel();

    return NexusAPI.chat(model, apiMessages, { temperature: _temperature, max_tokens: _maxTokens })
      .then(function(content) {
        if (typeof callback === 'function') callback(null, content);
        return content;
      })
      .catch(function(err) {
        if (typeof callback === 'function') callback(err, null);
        throw err;
      });
  }

  function deleteMessage(index) {
    if (index >= 0 && index < messages.length) {
      messages.splice(index, 1);
      if (typeof onMessagesChange === 'function') onMessagesChange(messages);
    }
  }

  return {
    newChat: newChat,
    loadChat: loadChat,
    deleteHistory: deleteHistory,
    addMessage: addMessage,
    updateLastAssistant: updateLastAssistant,
    sendMessage: sendMessage,
    cancelStream: cancelStream,
    deleteMessage: deleteMessage,
    updateMessage: updateMessage,
    getMessages: getMessages,
    getHistoryList: getHistoryList,
    loadHistory: loadHistory,
    analyzeCode: analyzeCode,
    onMessagesChange: onMessagesChangeCallback,
    isStreaming: function() { return isStreaming; },
    branch: branch,
    requestNotify: requestNotify,
    notifyResponse: notifyResponse,
    getSystemPrompt: function() { return _systemPrompt; },
    setSystemPrompt: function(p) { _systemPrompt = p; },
    getTemperature: function() { return _temperature; },
    setTemperature: function(t) { _temperature = t; },
    getMaxTokens: function() { return _maxTokens; },
    setMaxTokens: function(m) { _maxTokens = m; },
    isRagEnabled: function() { return _ragEnabled; },
    setRagEnabled: function(v) { _ragEnabled = v; },
    getRagResults: function() { return _ragMaxResults; },
    setRagResults: function(v) { _ragMaxResults = v; },
    getLastRagContext: function() { return _lastRagContext; }
  };
})();







