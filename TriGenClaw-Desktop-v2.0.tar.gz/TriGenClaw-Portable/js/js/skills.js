/* ========================================
   Skill 商店核心模块 - P3
   30+ 预设技能、分类筛选、安装、自定义创建
   ======================================== */
var NexusSkills = (function() {
  'use strict';

  // ===== 30+ 预设 Skill =====
  var SKILLS = [
    { id: 'web-dev', name: '全栈 Web 开�?, icon: '🌐', cat: 'development', desc: '从零搭建完整 Web 应用（前�?后端+数据库）', prompt: '你是一个全�?Web 开发专家，精�?HTML/CSS/JS, Node.js, React, Vue 等框架�?, tokens: 4096, temp: 0.7, tools: ['code','terminal'] },
    { id: 'rest-api', name: 'REST API 开�?, icon: '🔗', cat: 'development', desc: '设计、开发和文档�?RESTful API', prompt: '你是一�?API 开发专家，精�?RESTful API 设计�?OpenAPI 规范�?, tokens: 4096, temp: 0.5, tools: ['code','terminal'] },
    { id: 'code-review', name: '代码审查', icon: '👁�?, cat: 'development', desc: '全面的代码质量审查和最佳实践建�?, prompt: '你是一个代码审查专家，严格检查代码质量、安全性和性能�?, tokens: 4096, temp: 0.3, tools: ['code'] },
    { id: 'unit-test', name: '单元测试', icon: '🧪', cat: 'testing', desc: '编写全面的单元测试用例（Jest/Mocha/JUnit�?, prompt: '你是一个测试专家，精通单元测试框架和测试驱动开发�?, tokens: 4096, temp: 0.4, tools: ['code','terminal'] },
    { id: 'e2e-test', name: 'E2E 测试', icon: '🎯', cat: 'testing', desc: '端到端自动化测试（Playwright/Cypress/Selenium�?, prompt: '你是一�?E2E 测试专家，精�?Playwright �?Cypress�?, tokens: 4096, temp: 0.4, tools: ['code','terminal'] },
    { id: 'performance', name: '性能优化', icon: '�?, cat: 'optimization', desc: '代码和系统性能分析与优�?, prompt: '你是一个性能优化专家，精�?Profiling、缓存策略和代码优化�?, tokens: 4096, temp: 0.5, tools: ['code','terminal'] },
    { id: 'refactoring', name: '代码重构', icon: '🔄', cat: 'optimization', desc: '代码重构、设计模式应用、技术债务清理', prompt: '你是一个重构专家，精通设计模式和代码重构技术�?, tokens: 4096, temp: 0.5, tools: ['code'] },
    { id: 'debugging', name: '调试助手', icon: '🐛', cat: 'development', desc: 'BUG 分析和修复建�?, prompt: '你是一个调试专家，擅长分析错误日志和定�?Bug�?, tokens: 4096, temp: 0.5, tools: ['code','terminal'] },
    { id: 'code-gen', name: '代码生成', icon: '�?, cat: 'development', desc: '根据描述生成代码片段和完整文�?, prompt: '你是一个代码生成专家，根据需求生成高质量代码�?, tokens: 8192, temp: 0.6, tools: ['code'] },
    { id: 'database', name: '数据库设�?, icon: '🗄�?, cat: 'data', desc: '数据�?Schema 设计、SQL 优化、ORM 配置', prompt: '你是一个数据库专家，精�?SQL、NoSQL、ORM 和查询优化�?, tokens: 4096, temp: 0.5, tools: ['code','terminal'] },
    { id: 'data-analysis', name: '数据分析', icon: '📊', cat: 'data', desc: '数据清洗、统计分析、可视化报告', prompt: '你是一个数据分析专家，精�?Pandas、NumPy 和数据可视化�?, tokens: 4096, temp: 0.6, tools: ['code','file'] },
    { id: 'excel', name: 'Excel 处理', icon: '📗', cat: 'data', desc: 'Excel 文件读写、公式生成、数据透视', prompt: '你是一�?Excel 专家，精通公式、VBA 和数据处理�?, tokens: 4096, temp: 0.5, tools: ['code','file'] },
    { id: 'pdf', name: 'PDF 处理', icon: '📄', cat: 'data', desc: 'PDF 生成、解析、提取和转换', prompt: '你是一�?PDF 处理专家，精�?PDF 生成和解析库�?, tokens: 4096, temp: 0.5, tools: ['code','file'] },
    { id: 'csv', name: 'CSV 数据处理', icon: '📋', cat: 'data', desc: 'CSV 文件处理、转换、批量操�?, prompt: '你是一个数据处理专家，精�?CSV 和相关数据格式�?, tokens: 4096, temp: 0.5, tools: ['code','file'] },
    { id: 'docker', name: 'Docker 管理', icon: '🐳', cat: 'devops', desc: 'Dockerfile 编写、容器编排、镜像优�?, prompt: '你是一�?Docker 专家，精通容器化部署�?Docker Compose�?, tokens: 4096, temp: 0.5, tools: ['code','terminal'] },
    { id: 'kubernetes', name: 'Kubernetes', icon: '☸️', cat: 'devops', desc: 'K8s 配置、部署、服务发现、自动伸�?, prompt: '你是一�?K8s 专家，精通容器编排和云原生架构�?, tokens: 4096, temp: 0.5, tools: ['code','terminal'] },
    { id: 'ci-cd', name: 'CI/CD 流水�?, icon: '🔧', cat: 'devops', desc: 'GitHub Actions/GitLab CI/Jenkins 流水线配�?, prompt: '你是一�?CI/CD 专家，精通持续集成和持续部署工具�?, tokens: 4096, temp: 0.5, tools: ['code','terminal'] },
    { id: 'git', name: 'Git 管理', icon: '🔀', cat: 'devops', desc: 'Git 操作、分支策略、冲突解�?, prompt: '你是一�?Git 专家，精通版本控制和分支管理�?, tokens: 4096, temp: 0.5, tools: ['code','terminal'] },
    { id: 'security', name: '安全审计', icon: '🔒', cat: 'security', desc: '代码安全审查、漏洞检测、安全加�?, prompt: '你是一个安全专家，精�?OWASP Top 10 和安全编码实践�?, tokens: 4096, temp: 0.4, tools: ['code'] },
    { id: 'auth', name: '认证授权', icon: '🛡�?, cat: 'security', desc: 'OAuth/JWT/SAML 认证系统设计与实�?, prompt: '你是一个认证专家，精�?OAuth 2.0、JWT �?SSO�?, tokens: 4096, temp: 0.5, tools: ['code'] },
    { id: 'mobile-ios', name: 'iOS 开�?, icon: '📱', cat: 'mobile', desc: 'Swift/SwiftUI iOS 应用开�?, prompt: '你是一�?iOS 开发专家，精�?Swift �?SwiftUI�?, tokens: 4096, temp: 0.6, tools: ['code','terminal'] },
    { id: 'mobile-android', name: 'Android 开�?, icon: '🤖', cat: 'mobile', desc: 'Kotlin/Compose Android 应用开�?, prompt: '你是一�?Android 开发专家，精�?Kotlin �?Jetpack Compose�?, tokens: 4096, temp: 0.6, tools: ['code','terminal'] },
    { id: 'graphql', name: 'GraphQL API', icon: '�?, cat: 'development', desc: 'GraphQL Schema 设计、Resolver 实现、Apollo', prompt: '你是一�?GraphQL 专家，精�?Schema 设计�?Apollo 生态�?, tokens: 4096, temp: 0.5, tools: ['code','terminal'] },
    { id: 'graphql', name: 'GraphQL API', icon: '�?, cat: 'development', desc: 'GraphQL Schema/Resolver/Apollo', prompt: '你是一�?GraphQL 专家，精�?Schema 设计�?Apollo�?, tokens: 4096, temp: 0.5, tools: ['code','terminal'] },
    { id: 'web-scraping', name: '网页爬虫', icon: '🕸�?, cat: 'data', desc: '网页数据抓取、解析和结构化存�?, prompt: '你是一个爬虫专家，精通数据抓取和反爬策略�?, tokens: 4096, temp: 0.6, tools: ['code','terminal','web'] },
    { id: 'documentation', name: '文档生成', icon: '📝', cat: 'development', desc: 'API 文档、用户手册、技术博客自动生�?, prompt: '你是一个技术写作专家，擅长生成清晰的技术文档�?, tokens: 4096, temp: 0.5, tools: ['code','file'] },
    { id: 'translation', name: '代码翻译', icon: '🌍', cat: 'development', desc: '代码语言转换（Python/JS/Java/Go/Rust 等）', prompt: '你是一个多语言编程专家，精通代码语言转换�?, tokens: 4096, temp: 0.4, tools: ['code'] },
    { id: 'architecture', name: '系统架构', icon: '🏗�?, cat: 'design', desc: '系统架构设计、技术选型、微服务拆分', prompt: '你是一个架构师，精通分布式系统和微服务架构�?, tokens: 8192, temp: 0.6, tools: ['code'] },
    { id: 'ui-design', name: 'UI 设计助手', icon: '🎨', cat: 'design', desc: 'UI 组件设计、样式建议、CSS 生成', prompt: '你是一�?UI 设计专家，精�?CSS 和设计系统�?, tokens: 4096, temp: 0.7, tools: ['code','file'] },
    { id: 'nlp', name: '自然语言处理', icon: '🧠', cat: 'ai', desc: '文本分析、情感分析、命名实体识�?, prompt: '你是一�?NLP 专家，精通文本分析和语言模型�?, tokens: 4096, temp: 0.5, tools: ['code','file'] },
    { id: 'ml-pipeline', name: 'ML 流水�?, icon: '🔬', cat: 'ai', desc: '机器学习流程搭建、特征工程、模型评�?, prompt: '你是一�?ML 专家，精�?Scikit-learn �?ML 流水线�?, tokens: 4096, temp: 0.5, tools: ['code','terminal'] },
    { id: 'image-proc', name: '图像处理', icon: '🖼�?, cat: 'ai', desc: '图像处理、OCR、计算机视觉', prompt: '你是一�?CV 专家，精�?OpenCV 和图像处理�?, tokens: 4096, temp: 0.5, tools: ['code','file'] },
    { id: 'regex', name: '正则表达�?, icon: '🔤', cat: 'development', desc: '正则表达式编写、测试、优�?, prompt: '你是一个正则表达式专家，精通各种正则引擎�?, tokens: 2048, temp: 0.3, tools: ['code'] },
    { id: 'cli-tool', name: 'CLI 工具开�?, icon: '💻', cat: 'development', desc: '命令行工具设计、开发、打包发�?, prompt: '你是一�?CLI 开发专家，精通命令行工具开发�?, tokens: 4096, temp: 0.5, tools: ['code','terminal','file'] },
    { id: 'ab-testing', name: 'A/B 测试', icon: '📈', cat: 'data', desc: '实验设计、统计分析、结果解�?, prompt: '你是一个实验设计专家，精�?A/B 测试和统计分析�?, tokens: 4096, temp: 0.6, tools: ['code','file'] }
  ];

  var SKILL_CATEGORIES = [
    { id: 'all', name: 'All', icon: '🔀' },
    { id: 'development', name: 'Development', icon: '💻' },
    { id: 'testing', name: 'Testing', icon: '🧪' },
    { id: 'optimization', name: 'Optimization', icon: '�? },
    { id: 'data', name: 'Data', icon: '📊' },
    { id: 'devops', name: 'DevOps', icon: '🔧' },
    { id: 'security', name: 'Security', icon: '🔒' },
    { id: 'mobile', name: 'Mobile', icon: '📱' },
    { id: 'design', name: 'Design', icon: '🎨' },
    { id: 'ai', name: 'AI/ML', icon: '🧠' }
  ];

  var STORAGE_KEY = 'nx_installed_skills';
  var CUSTOM_KEY = 'nx_custom_skills';
  var installedSkills = {};
  var customSkills = [];
  var currentCategory = 'all';
  var currentSearch = '';

  // DOM refs
  var gridEl, installedGridEl, customGridEl;
  var categoriesEl, searchInput;

  // ===== 初始�?=====
  function init() {
    gridEl = document.getElementById('skillsGrid');
    installedGridEl = document.getElementById('installedGrid');
    customGridEl = document.getElementById('customGrid');
    categoriesEl = document.getElementById('skillsCategories');
    searchInput = document.getElementById('skillsSearchInput');

    loadInstalled();
    loadCustom();

    if (!gridEl) return;
    renderCategories();
    renderSkills();

    setupSearch();
    setupTabs();
    setupCustomButton();
    setupImportButton();
  }

  // ===== 数据加载 =====
  function loadInstalled() {
    try {
      var data = localStorage.getItem(STORAGE_KEY);
      installedSkills = data ? JSON.parse(data) : {};
    } catch(e) { installedSkills = {}; }
  }

  function saveInstalled() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(installedSkills)); } catch(e) {}
  }

  function loadCustom() {
    try {
      var data = localStorage.getItem(CUSTOM_KEY);
      customSkills = data ? JSON.parse(data) : [];
    } catch(e) { customSkills = []; }
  }

  function saveCustom() {
    try { localStorage.setItem(CUSTOM_KEY, JSON.stringify(customSkills)); } catch(e) {}
  }

  function isInstalled(skillId) {
    return !!installedSkills[skillId];
  }

  function isCustom(skillId) {
    for (var i = 0; i < customSkills.length; i++) {
      if (customSkills[i].id === skillId) return true;
    }
    return false;
  }

  // ===== 分类渲染 =====
  function renderCategories() {
    if (!categoriesEl) return;
    var html = '';
    for (var i = 0; i < SKILL_CATEGORIES.length; i++) {
      var cat = SKILL_CATEGORIES[i];
      var active = cat.id === currentCategory ? ' active' : '';
      html += '<button class="skill-cat' + active + '" data-cat="' + cat.id + '">' + cat.icon + ' ' + cat.name + '</button>';
    }
    categoriesEl.innerHTML = html;

    var btns = categoriesEl.querySelectorAll('.skill-cat');
    for (var j = 0; j < btns.length; j++) {
      (function(btn) {
        btn.addEventListener('click', function() {
          currentCategory = this.getAttribute('data-cat');
          categoriesEl.querySelectorAll('.skill-cat').forEach(function(b) { b.classList.remove('active'); });
          this.classList.add('active');
          renderSkills();
        });
      })(btns[j]);
    }
  }

  // ===== 技能卡片渲�?=====
  function renderSkills() {
    if (!gridEl) return;
    var filtered = getFilteredSkills();
    var html = '';
    for (var i = 0; i < filtered.length; i++) {
      html += renderCard(filtered[i]);
    }
    gridEl.innerHTML = html || '<div class="skills-view-placeholder"><p>No skills found.</p></div>';
    bindCardEvents(gridEl);

    // 已安装视�?    renderInstalled();
    // 自定义视�?    renderCustom();
  }

  function getFilteredSkills() {
    var skills = SKILLS.slice();
    // 分类过滤
    if (currentCategory !== 'all') {
      skills = skills.filter(function(s) { return s.cat === currentCategory; });
    }
    // 搜索过滤
    if (currentSearch) {
      var q = currentSearch.toLowerCase();
      skills = skills.filter(function(s) {
        return s.name.toLowerCase().indexOf(q) >= 0 ||
               s.desc.toLowerCase().indexOf(q) >= 0 ||
               s.cat.indexOf(q) >= 0;
      });
    }
    return skills;
  }

  function renderCard(skill) {
    var installed = isInstalled(skill.id) || isCustom(skill.id);
    var btnClass = installed ? 'skill-btn installed' : 'skill-btn';
    var btnText = installed ? '�?Installed' : 'Install';
    var catName = '';
    for (var c = 0; c < SKILL_CATEGORIES.length; c++) {
      if (SKILL_CATEGORIES[c].id === skill.cat) { catName = SKILL_CATEGORIES[c].icon + ' ' + SKILL_CATEGORIES[c].name; break; }
    }
    return '<div class="skill-card" data-id="' + skill.id + '">' +
      '<div class="skill-card-icon">' + (skill.icon || '🔧') + '</div>' +
      '<div class="skill-card-body">' +
      '<div class="skill-card-name">' + skill.name + '</div>' +
      '<div class="skill-card-cat">' + catName + '</div>' +
      '<div class="skill-card-desc">' + skill.desc + '</div>' +
      '</div>' +
      '<button class="' + btnClass + '">' + btnText + '</button>' +
      (installed ? '' : '<span class="skill-tokens">' + (skill.tokens/1024).toFixed(0) + 'K</span>') +
      '</div>';
  }

  function bindCardEvents(container) {
    var btns = container.querySelectorAll('.skill-btn:not(.installed)');
    for (var i = 0; i < btns.length; i++) {
      (function(btn) {
        btn.addEventListener('click', function() {
          var card = this.closest('.skill-card');
          var id = card.getAttribute('data-id');
          installSkill(id);
        });
      })(btns[i]);
    }
  }

  // ===== 安装/卸载 =====
  function installSkill(skillId) {
    if (isInstalled(skillId) || isCustom(skillId)) return;
    // 找到技能信�?    var skill = null;
    for (var i = 0; i < SKILLS.length; i++) {
      if (SKILLS[i].id === skillId) { skill = SKILLS[i]; break; }
    }
    if (!skill) { NexusUI.toast('Skill not found.', 'error'); return; }

    installedSkills[skillId] = {
      id: skillId,
      name: skill.name,
      icon: skill.icon,
      prompt: skill.prompt,
      tokens: skill.tokens,
      temp: skill.temp,
      tools: skill.tools,
      installedAt: Date.now()
    };
    saveInstalled();

    // Register as plugin
    if (typeof NexusPlugins !== 'undefined' && NexusPlugins.register) {
      NexusPlugins.register({
        id: 'skill_' + skillId,
        name: skill.name,
        hooks: {
          onBeforeSend: function(msgs) {
            if (skill.prompt) { msgs.unshift({ role: 'system', content: skill.prompt }); }
            return msgs;
          }
        }
      });
    }

    renderSkills();

    // 通知已安�?    NexusUI.toast('Installed: ' + skill.name, 'success');

    // 触发自定义事件，其他模块可监�?    var event = new CustomEvent('skill-installed', { detail: { skill: installedSkills[skillId] } });
    document.dispatchEvent(event);
  }

  function uninstallSkill(skillId) {
    delete installedSkills[skillId];
    saveInstalled();

    // Register as plugin
    if (typeof NexusPlugins !== 'undefined' && NexusPlugins.register) {
      NexusPlugins.register({
        id: 'skill_' + skillId,
        name: skill.name,
        hooks: {
          onBeforeSend: function(msgs) {
            if (skill.prompt) { msgs.unshift({ role: 'system', content: skill.prompt }); }
            return msgs;
          }
        }
      });
    }

    renderSkills();
    NexusUI.toast('Uninstalled', 'info');
  }

  // ===== 已安装视�?=====
  function renderInstalled() {
    if (!installedGridEl) return;
    var ids = Object.keys(installedSkills);
    var placeholder = document.getElementById('installedPlaceholder');
    if (placeholder) placeholder.style.display = ids.length > 0 ? 'none' : 'flex';

    if (ids.length === 0) { installedGridEl.innerHTML = ''; return; }

    var html = '';
    for (var i = 0; i < ids.length; i++) {
      var skill = installedSkills[ids[i]];
      html += '<div class="skill-card installed" data-id="' + skill.id + '">' +
        '<div class="skill-card-icon">' + (skill.icon || '🔧') + '</div>' +
        '<div class="skill-card-body">' +
        '<div class="skill-card-name">' + skill.name + '</div>' +
        '<div class="skill-card-desc">Active</div>' +
        '</div>' +
        '<button class="skill-btn uninstall">Remove</button>' +
        '</div>';
    }
    installedGridEl.innerHTML = html;

    var uninstallBtns = installedGridEl.querySelectorAll('.uninstall');
    for (var j = 0; j < uninstallBtns.length; j++) {
      (function(btn) {
        btn.addEventListener('click', function() {
          var card = this.closest('.skill-card');
          var id = card.getAttribute('data-id');
          uninstallSkill(id);
        });
      })(uninstallBtns[j]);
    }
  }

  // ===== 自定义技�?=====
  function renderCustom() {
    if (!customGridEl) return;
    var placeholder = document.getElementById('customPlaceholder');
    if (placeholder) placeholder.style.display = customSkills.length > 0 ? 'none' : 'flex';

    if (customSkills.length === 0) { customGridEl.innerHTML = ''; return; }

    var html = '';
    for (var i = 0; i < customSkills.length; i++) {
      var skill = customSkills[i];
      html += '<div class="skill-card installed" data-id="' + skill.id + '">' +
        '<div class="skill-card-icon">' + (skill.icon || '🔧') + '</div>' +
        '<div class="skill-card-body">' +
        '<div class="skill-card-name">' + skill.name + '</div>' +
        '<div class="skill-card-desc">' + (skill.desc || 'Custom skill') + '</div>' +
        '</div>' +
        '<button class="skill-btn export-skill" data-id="' + skill.id + '">Export</button>' +
        '<button class="skill-btn uninstall" data-id="' + skill.id + '">Delete</button>' +
        '</div>';
    }
    customGridEl.innerHTML = html;

    // Export buttons
    var exportBtns = customGridEl.querySelectorAll('.export-skill');
    for (var j = 0; j < exportBtns.length; j++) {
      (function(btn) {
        btn.addEventListener('click', function() {
          var id = this.getAttribute('data-id');
          exportSkill(id);
        });
      })(exportBtns[j]);
    }

    // Delete buttons
    var deleteBtns = customGridEl.querySelectorAll('.uninstall');
    for (var k = 0; k < deleteBtns.length; k++) {
      (function(btn) {
        btn.addEventListener('click', function() {
          var card = this.closest('.skill-card');
          var id = card.getAttribute('data-id');
          deleteCustomSkill(id);
        });
      })(deleteBtns[k]);
    }
  }function deleteCustomSkill(skillId) {
    customSkills = customSkills.filter(function(s) { return s.id !== skillId; });
    delete installedSkills[skillId];
    saveCustom();
    saveInstalled();

    // Register as plugin
    if (typeof NexusPlugins !== 'undefined' && NexusPlugins.register) {
      NexusPlugins.register({
        id: 'skill_' + skillId,
        name: skill.name,
        hooks: {
          onBeforeSend: function(msgs) {
            if (skill.prompt) { msgs.unshift({ role: 'system', content: skill.prompt }); }
            return msgs;
          }
        }
      });
    }

    renderSkills();
    NexusUI.toast('Deleted', 'info');
  }

  function setupCustomButton() {
    var btn = document.getElementById('skillsCustomBtn');
    if (!btn) return;
    btn.addEventListener('click', showCreateModal);
  }

  function showCreateModal() {
    // 创建模态框
    var overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML =
      '<div class="modal skills-modal">' +
      '<div class="modal-header"><span>Create Custom Skill</span><button class="modal-close">×</button></div>' +
      '<div class="modal-body">' +
      '<div class="form-group"><label>Skill Name</label><input type="text" id="createSkillName" placeholder="e.g., My Analyzer"></div>' +
      '<div class="form-group"><label>Description</label><input type="text" id="createSkillDesc" placeholder="Short description"></div>' +
      '<div class="form-group"><label>Icon (emoji)</label><input type="text" id="createSkillIcon" value="🔧" maxlength="2"></div>' +
      '<div class="form-group"><label>System Prompt</label><textarea id="createSkillPrompt" rows="4" placeholder="Describe what this skill does..."></textarea></div>' +
      '<div class="form-group"><label>Trigger Words (comma separated)</label><input type="text" id="createSkillTriggers" placeholder="analyze, scan, check"></div>' +
      '<div class="form-group"><label>Tool Permissions</label>' +
      '<div class="tool-checks">' +
      '<label><input type="checkbox" class="create-tool" value="code" checked> Code</label>' +
      '<label><input type="checkbox" class="create-tool" value="terminal"> Terminal</label>' +
      '<label><input type="checkbox" class="create-tool" value="file"> File</label>' +
      '<label><input type="checkbox" class="create-tool" value="web"> Web</label>' +
      '<label><input type="checkbox" class="create-tool" value="image"> Image</label>' +
      '</div></div>' +
      '<div class="form-group"><label>Max Tokens</label><input type="number" id="createSkillTokens" value="4096" min="1024" max="32768"></div>' +
      '</div>' +
      '<div class="modal-footer"><button id="createSkillSave" class="btn btn-sm btn-primary">Create</button><button id="createSkillCancel" class="btn btn-sm btn-ghost">Cancel</button></div>' +
      '</div>';

    document.body.appendChild(overlay);

    overlay.querySelector('.modal-close').onclick = function() { overlay.remove(); };
    overlay.querySelector('#createSkillCancel').onclick = function() { overlay.remove(); };
    overlay.querySelector('#createSkillSave').onclick = function() {
      var name = overlay.querySelector('#createSkillName').value.trim();
      if (!name) { NexusUI.toast('Please enter a name.', 'error'); return; }
      var id = 'custom_' + Date.now().toString(36);
      var tools = [];
      overlay.querySelectorAll('.create-tool:checked').forEach(function(cb) { tools.push(cb.value); });
      var skill = {
        id: id,
        name: name,
        icon: overlay.querySelector('#createSkillIcon').value || '🔧',
        desc: overlay.querySelector('#createSkillDesc').value || 'Custom skill',
        prompt: overlay.querySelector('#createSkillPrompt').value || name + ' assistant',
        triggers: overlay.querySelector('#createSkillTriggers').value.split(',').map(function(s) { return s.trim(); }).filter(Boolean),
        tokens: parseInt(overlay.querySelector('#createSkillTokens').value) || 4096,
        temp: 0.5,
        tools: tools,
        cat: 'custom',
        createdAt: Date.now()
      };
      customSkills.push(skill);
      installedSkills[id] = {
        id: id, name: skill.name, icon: skill.icon,
        prompt: skill.prompt, tokens: skill.tokens,
        temp: skill.temp, tools: skill.tools,
        installedAt: Date.now()
      };
      saveCustom();
      saveInstalled();
      overlay.remove();
      renderSkills();
      NexusUI.toast('Created: ' + name, 'success');
    };

    overlay.addEventListener('click', function(e) {
      if (e.target === overlay) overlay.remove();
    });

    // 自动聚焦
    setTimeout(function() { overlay.querySelector('#createSkillName').focus(); }, 100);
  }

  // ===== 搜索 =====
  function setupSearch() {
    if (!searchInput) return;
    searchInput.addEventListener('input', function() {
      currentSearch = this.value;
      renderSkills();
    });
  }

  // ===== Tab 切换 =====
  function setupTabs() {
    var tabs = document.querySelectorAll('.skills-tab');
    for (var i = 0; i < tabs.length; i++) {
      (function(tab) {
        tab.addEventListener('click', function() {
          var target = this.getAttribute('data-stab');
          tabs.forEach(function(t) { t.classList.remove('active'); });
          this.classList.add('active');

          var views = ['skillsBrowse', 'skillsInstalled', 'skillsCustom'];
          var idMap = { browse: 'skillsBrowse', installed: 'skillsInstalled', custom: 'skillsCustom' };
          for (var v = 0; v < views.length; v++) {
            document.getElementById(views[v])?.classList.remove('active');
          }
          var targetEl = document.getElementById(idMap[target]);
          if (targetEl) targetEl.classList.add('active');

          // 重新渲染当前视图
          if (target === 'installed') renderInstalled();
          if (target === 'custom') renderCustom();
        });
      })(tabs[i]);
    }
  }

  // ===== 获取已安装技能（供其他模块使用） =====
    // ===== 导出技�?=====
  function exportSkill(skillId) {
    // 查找技能（自定义或预设�?    var skill = null;
    for (var i = 0; i < customSkills.length; i++) {
      if (customSkills[i].id === skillId) { skill = customSkills[i]; break; }
    }
    if (!skill) {
      for (var j = 0; j < SKILLS.length; j++) {
        if (SKILLS[j].id === skillId) { skill = SKILLS[j]; break; }
      }
    }
    if (!skill) { NexusUI.toast('Skill not found', 'error'); return; }

    var exportData = {
      type: 'nexus-skill',
      version: 1,
      skill: {
        name: skill.name,
        icon: skill.icon || '🔧',
        desc: skill.desc || '',
        prompt: skill.prompt || '',
        category: skill.cat || 'custom',
        tokens: skill.tokens || 4096,
        temp: skill.temp || 0.5,
        tools: skill.tools || ['code'],
        triggers: skill.triggers || []
      }
    };

    var blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = (skill.name || 'skill').replace(/[^a-zA-Z0-9\u4e00-\u9fff_-]/g, '_') + '.skill.json';
    a.click();
    URL.revokeObjectURL(url);
    NexusUI.toast('Exported: ' + skill.name, 'success');
  }

  // ===== 导入技�?=====
  function setupImportButton() {
    var importBtn = document.createElement('button');
    importBtn.className = 'btn btn-sm btn-ghost';
    importBtn.innerHTML = 'Import';
    importBtn.title = 'Import skill (.skill.json)';
    var actions = document.querySelector('.skills-actions');
    if (actions) {
      importBtn.addEventListener('click', function() {
        var input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json';
        input.style.display = 'none';
        input.addEventListener('change', function(e) {
          var file = e.target.files[0];
          if (!file) return;
          var reader = new FileReader();
          reader.onload = function(ev) {
            try {
              var data = JSON.parse(ev.target.result);
              if (data.type !== 'nexus-skill' || !data.skill) {
                NexusUI.toast('Invalid skill file', 'error');
                return;
              }
              var s = data.skill;
              var id = 'imported_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
              var skill = {
                id: id,
                name: s.name || 'Imported Skill',
                icon: s.icon || '🔧',
                desc: s.desc || '',
                prompt: s.prompt || '',
                triggers: s.triggers || [],
                tokens: s.tokens || 4096,
                temp: s.temp || 0.5,
                tools: s.tools || ['code'],
                cat: s.category || 'custom',
                createdAt: Date.now()
              };
              customSkills.push(skill);
              installedSkills[id] = {
                id: id, name: skill.name, icon: skill.icon,
                prompt: skill.prompt, tokens: skill.tokens,
                temp: skill.temp, tools: skill.tools,
                installedAt: Date.now()
              };
              saveCustom();
              saveInstalled();
              renderSkills();
              NexusUI.toast('Imported: ' + skill.name, 'success');
            } catch(err) {
              NexusUI.toast('Import failed: ' + err.message, 'error');
            }
          };
          reader.readAsText(file);
          input.value = '';
        });
        document.body.appendChild(input);
        input.click();
        setTimeout(function() { input.remove(); }, 1000);
      });
      actions.appendChild(importBtn);
    }
  }function getInstalledSkills() {
    var result = {};
    var ids = Object.keys(installedSkills);
    for (var i = 0; i < ids.length; i++) {
      result[ids[i]] = installedSkills[ids[i]];
    }
    // 也包含预�?    for (var j = 0; j < SKILLS.length; j++) {
      if (installedSkills[SKILLS[j].id]) {
        result[SKILLS[j].id] = result[SKILLS[j].id] || SKILLS[j];
      }
    }
    return result;
  }

  return {
    init: init,
    getInstalled: getInstalledSkills,
    installSkill: installSkill,
    uninstallSkill: uninstallSkill
  };
})();

